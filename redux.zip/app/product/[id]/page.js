"use client"
import React, { useEffect, useState } from 'react'
import { useParams, useRouter } from 'next/navigation'
import Link from 'next/link'
import rightArrow from '@/public/assets/image/right_arrow.png'
import Slider from "react-slick";
import "slick-carousel/slick/slick.css";
import "slick-carousel/slick/slick-theme.css";
import productIMg from '@/public/assets/image/banner_img.png'
import Tab from 'react-bootstrap/Tab';
import Tabs from 'react-bootstrap/Tabs';
import star_fill from '@/public/assets/image/start_fill.png'
import star_default from '@/public/assets/image/star_default.png'
import FeatureProducts from '@/component/FeatureProducts'
import buy_icon from '@/public/assets/image/buy_icon.png'
import wishlist_icon from '@/public/assets/image/wishlist_icon.png'
import share_icon from '@/public/assets/image/share_icon.png'
import plus_icon from '@/public/assets/image/plus_icon.png'
import minus_icon from '@/public/assets/image/minus_icon.png'
import zoom from '@/public/assets/image/zoom-out.png'
import "react-responsive-carousel/lib/styles/carousel.min.css"; // requires a loader
import { Carousel } from 'react-responsive-carousel';
import { AddCart, AddWishlist, GetCart, GetProductDetails, GetProfile, GetWishlist, SaveReview } from '@/utils/Apirequest'
import Loader from '@/utils/Loader'
import { GetcartAction, GetWishlistAction, HeaderDropdown } from '@/redux/reducer/DataflowReducer'
import { toast } from 'react-toastify'
import { useDispatch, useSelector } from 'react-redux'
import Modal from 'react-bootstrap/Modal';
import { Rating } from 'react-simple-star-rating'
import RelatedProducts from '@/component/RelatedProducts'
import Lightbox from "yet-another-react-lightbox";
import Thumbnails from "yet-another-react-lightbox/plugins/thumbnails";
import "yet-another-react-lightbox/styles.css";
import "yet-another-react-lightbox/plugins/thumbnails.css";
import Zoom from "yet-another-react-lightbox/plugins/zoom";
import Fullscreen from "yet-another-react-lightbox/plugins/fullscreen";
import heartsolid from '@/public/assets/image/heart.png'


export default function Page(){

    const [loading, setloading] = useState(false)
    const [featureproduct, setfeatureproduct] = useState([])
    const [productinfo, setproductinfo] = useState('')
    const [qty, setqty] = useState(1)
    const [variation, setvariation] = useState([])
    const [variationalue, setvariationalue] = useState("")
    const [fname, setfname] = useState('')
    const [lname, setlname] = useState('')
    const [email, setemail] = useState('')
    const [show, setShow] = useState(false);
    const [rating, setRating] = useState(0)
    const [comment, setcomment] = useState("")
    const [title, settitle] = useState("")
    const [open, setOpen] = React.useState(false);
    const [lightboxImage, setlightboxImage] = useState([])
    const [defaulttab, setdefaulttab] = useState("description")
    const { id} = useParams()
    const datareducer = useSelector((state) => state.Dataflowreducer)
    

    const router = useRouter();

    let dispatch = useDispatch()

    // const settings = {
    //     dots: true,
    //     infinite: true,
    //     speed: 500,
    //     slidesToShow: 1,
    //     slidesToScroll: 1,
    //     customPaging: i => (
    //       <div className='thumbnail_image'>
    //         {i.category}
    //       </div>
    //     )
    //   };
    const handleClose = () => setShow(false);

    const handleShow = () => {
      setShow(true)

    };
  

    useEffect(()=>{
     
          GetApiRequest()

             if(datareducer?.isToggle){
                 dispatch(HeaderDropdown(false))
                              }

          datareducer?.token != '' &&
          GetprofilApiRequest()
       
    },[])

    const GetApiRequest = async () =>{
        setloading(true)
        let payload = {
            "product_id": id
        }
     
        let responsedata =  await GetProductDetails(payload)
        setloading(false)
        if(responsedata?.response_code == 200){

            var Arr = []

            responsedata?.data?.product_info?.product_images.forEach(elem =>{
                Arr.push({
                    'src':elem
                }) 
            })

            setlightboxImage(Arr)

            setfeatureproduct(responsedata?.data?.featured_product_list)

            let TempArr = []

            

            responsedata?.data?.product_info?.variation?.forEach(element => {
                TempArr.push({
                    ...element,
                    value:''
                })
            });
            setvariation(TempArr)

            setproductinfo(responsedata?.data?.product_info)
         
  
  
        }
       
      }

        const GetprofilApiRequest = async () =>{
        
           setloading(true)
              
           let responsedata =  await GetProfile()
        
           setloading(false)
         
           if(responsedata?.status){

              setfname(responsedata?.data?.first_name)
              setlname(responsedata?.data?.last_name)
              setemail(responsedata?.data?.email)
           }
          
         }

    async function AddCartHandle() {


        if(variation?.length > 0 )
        {
            if(variationalue == ''){
                toast.error("Please Select the size")
            } else  if(qty == 0){
                toast.error("Please added the quantity first")
            } else {
                let price = productinfo?.base_price.replace(',', '')

                var TemA = []
        
                variation?.forEach(element =>{
                    TemA.push(element.value)
                })
            
            
                setloading(true)
            
                let body = {
                    "product_id": productinfo?.id,
                    "product_qty": qty,
                    "product_rate": price,
                    "variations": TemA
                }
            
                const response = await AddCart(body)
                setloading(false)
            
                if(response?.status){
                  //  GetApiRequest()
                    let responsedata =  await GetCart()
                    dispatch(GetcartAction(responsedata?.data[0]?.cart_items))
                    GetApiRequest()
                    toast(response?.message)
                } else {
                    toast(response?.message)
                }
            }

        } else {
            if(qty == 0){
                toast.error("Please added the quantity first")
            } else {
                let price = productinfo?.base_price.replace(',', '')

                var TemA = []
        
                variation?.forEach(element =>{
                    TemA.push(element.value)
                })
            
            
                setloading(true)
            
                let body = {
                    "product_id": productinfo?.id,
                    "product_qty": qty,
                    "product_rate": price,
                    "variations": TemA
                }
            
                const response = await AddCart(body)
                setloading(false)
            
                if(response?.status){
                  //  GetApiRequest()
                    let responsedata =  await GetCart()
                    dispatch(GetcartAction(responsedata?.data[0]?.cart_items))
                    GetApiRequest()
                    toast(response?.message)
                } else {
                    toast(response?.message)
                }
            }
        }

    

    
    }


    async function VarietionHandle(value, i, items, key) {
        var arr = [...variation]
        arr[i][key] = value

        setvariation(arr)
        setvariationalue(value)
    }

     async function AddWishlistHandle(item) {
          setloading(true)
  
          let body = {
              "product_id": item?.id,
          }
  
          const response = await AddWishlist(body)
          setloading(false)
  
          if(response?.status){
              let responsedata =  await GetWishlist()
              dispatch(GetWishlistAction(responsedata?.data))
              GetApiRequest()
              toast(response?.message)
          } else {
              toast(response?.message)
          }
      }

      const handleRating = (rate) => {
        setRating(rate)
    
      }
 

      async function SubmitReview() {
        
        setloading(true)

        let body = {
            "product_id": id,
            "name": fname + ' ' + lname,
            "email": email,
            "rating": rating,
            "title": title,
            "comment": comment
        }

        let response = await SaveReview(body)
        setloading(false)
        if(response?.status){
            setShow(false)
            toast(response?.message)
        } else {
            toast(response?.message)
        }

        
      }


      async function AddCartHandleFromchild(item) {

        let price = item?.base_price.replace(',', '')
    
    
        setloading(true)
    
        let body = {
            "product_id": item?.id,
            "product_qty": 1,
            "product_rate": price,
            "variations": []
        }
    
        const response = await AddCart(body)
        setloading(false)
    
        if(response?.status){
          //  GetApiRequest()
            let responsedata =  await GetCart()
            dispatch(GetcartAction(responsedata?.data[0]?.cart_items))
            GetApiRequest()
            toast(response?.message)
        } else {
            toast(response?.message)
        }
    }
    
    
    async function AddWishListFromChild(item) {
       setloading(true)
      
              let body = {
                  "product_id": item?.id,
              }
      
              const response = await AddWishlist(body)
              setloading(false)
      
              if(response?.status){
                  let responsedata =  await GetWishlist()
                  dispatch(GetWishlistAction(responsedata?.data))
                  GetApiRequest()
                  toast(response?.message)
              } else {
                  toast(response?.message)
              }
    }



  return (

    <div className='inner-sec py-3'>
          {loading && <Loader/>}
    <div className='container'>
       
        <div className='breadcrames mb-5'>
            <ul>
                <li>
                    <Link href="/" >Home </Link>
                </li>
                <li>
                <img src={rightArrow.src} alt="icon" />
                </li>
            
                <li>
                <Link href={`/product/category/${productinfo?.main_category}`} >{productinfo?.parent__category_name} </Link>
                
                </li>
                <li>
                <img src={rightArrow.src} alt="icon" />
                </li>
                <li>
                    <b>{productinfo?.sub_category_name}</b>
                </li>
                <li>
                <img src={rightArrow.src} alt="icon" />
                </li>
                <li>
                    <b>{productinfo?.name}</b>
                </li>
            </ul>
        </div>
        <div className='row'>
            <div className='col-lg-7'>
                <div className='left-img'>
                <button onClick={() => setOpen(true)} className='zoomImage'><img src={zoom.src} /></button>
            <Carousel axis='vertical'>
     
            {productinfo?.product_images?.map((item, i)=>{
                return (
                    <div className='proImg' key={i}>
                         <img src={item} />
                    </div>
                )
            })}
               
          
            </Carousel>
           
            </div>
        
            </div>
            <div className='col-lg-5'>

                <div className='product-details'>
                    <h2>{productinfo?.name}</h2>
                    <ul  className='rating-list'>
                        <li>
                            <ul>
                             {Array(5).fill().map((_, i) => {
                                const ratingValue = i + 1;
                            return  <li key={i}><img src={ratingValue <= productinfo?.rating ? star_fill.src : star_default.src} /></li>
                            })}

                       
                                </ul>
                        </li>
                        <li>
                            <span>{productinfo?.rating}</span>
                        </li>
                        <li>
                            <label>{productinfo?.review_list?.length} <button onClick={()=>setdefaulttab('review')}>(Reviews)</button></label>
                        </li>
                        <li>
                            <label>SKU:</label>
                            <b> {productinfo?.product_sku}</b>
                        </li>
                    </ul>
                    <div dangerouslySetInnerHTML={{__html: productinfo?.short_description}} />
                    {/* <p>{productinfo?.short_description}</p> */}
                    {productinfo?.price_percentage == 'PERCENTAGE' ?  <h5>${productinfo?.base_price} <span>₹ {productinfo?.markup_price}</span></h5> :
                            
                            <h5>${productinfo?.base_price} </h5>
                            }
                   

                <ul className='product-varient'>
                    {variation?.length > 0 &&
                        variation?.map((item, index)=>{
                            return (
                                <li key={index}>
                                <label>{item?.attr_name}</label>
                                <select className='form-control' value={item?.value}
                                    onChange={(e)=>VarietionHandle(e.target.value, index, item, 'value')}
                                >
                                    <option>--Select--</option>
                                    {item?.attr_vals?.map((vari, i)=>{
                                        return <option key={i} value={vari?.attr_val_id} >{vari?.attr_val_name}</option>
                                    })}
                                  
                                </select>
                         </li>
                            )
                        })
                    }
                        
                        
                        
                </ul>
                
                      {productinfo?.product_qty <= 0 ?
                    <h5>Out of stock</h5>
                :
                <ul className='quantity-add'>
                    <li>
                        <div className='quantity-box'>
                             <button onClick={()=>setqty(qty - 1)} disabled={qty == 1 ? true : false}><img src={minus_icon.src}  /></button>
                            <input type='text' placeholder='QTY' value={qty} onChange={(e)=>setqty(e.target.value)} 
                             onKeyPress={(event) => {
                                if (!/[0-9]/.test(event.key)) {
                                  event.preventDefault();
                                }
                              }}
                            />
                            <button onClick={()=>setqty(qty + 1)}><img src={plus_icon.src} /></button>
                        </div>
                    </li>
                    {productinfo?.is_cart == 1 ?
                     <li>
                         <b>Item Added</b>
                     </li>
                    :
                    <li>
                    <button className='addtocartBtn' onClick={AddCartHandle}><img src={buy_icon.src}  /> Add to cart</button>
                </li>
                }
                   
                    {/* <li>
                        <Link href="#" className='buynowBtn'><img src={buy_icon.src} /> Buy Now</Link>
                     
                    </li> */}
               
                </ul>
                    }
                <ul className='wishlist-sec'>
                        <li>
                             {productinfo?.is_wishlist == 1 ?
                                                                    <button onClick={()=>{
                                                                        datareducer?.token != null ?
                                                                        AddWishlistHandle(productinfo)
                                                                        :
                                                                     
                                                                        router.push('/login')
                                                                        }}>
                                                                        <img src={heartsolid.src} className='heartIcon' />
                                                                    </button> 
                                                                        :
                            <button onClick={()=>{
                                                datareducer?.token != null ?
                                                AddWishlistHandle(productinfo)
                                                :
                                             
                                                router.push('/login')
                                                }}><img src={wishlist_icon.src} />  Add to wishlist</button>
                                            }
                        </li>
                        {datareducer?.token != null && 
                        <li>
                            <button onClick={()=>setShow(true)}>Give Review</button>
                        </li>
}
                        {/* <li>
                            <Link href="#"><img src={share_icon.src} /> Share this Product</Link>
                        </li> */}
                </ul>
                </div>

            </div>
        </div>
    
    <div className='pro-tab-details'>
    <Tabs
      activeKey={defaulttab}
      id="controlled-tab-example"
      className="mb-3"
      onSelect={(k) => setdefaulttab(k)}
    >
      <Tab eventKey="description" title="Description">
      <div dangerouslySetInnerHTML={{__html: productinfo?.long_description}} />
      </Tab>
      <Tab eventKey="review" title={`Reviews (${productinfo?.review_list?.length})`}>
      Reviews

{productinfo?.review_list?.length > 0 ? 
                            
      productinfo?.review_list?.map((reviews, i)=>{
        return (
            <div className='reviewList' key={i}>
                <div className='user-i'>
                    <img src={reviews?.user_profile_image} />
                    <div>
                    <b>{reviews?.name}</b>
                    <span>{reviews?.email}</span>
                    </div>
                   

                </div>
                <div className='user-r'>
                    <h5>{reviews?.title}</h5>
                    <p>{reviews?.comment}</p>
                </div>
                <ul>
                {Array(5).fill().map((_, i) => {
                const ratingValue = i + 1;
            return  <li key={i}><img src={ratingValue <= reviews?.rating ? star_fill.src : star_default.src} /></li>
            })}

        
                </ul>
            </div>
        )
      })

      :
      <h5>No Reviews</h5>
    }
      </Tab>
      {productinfo?.product_attributes?.length > 0 &&
       <Tab eventKey="attribute" title="Specification">
            {productinfo?.product_attributes?.map((item, i)=>{
                return (
                    <div className='productattr' key={i}>
                          <h5>{item?.attribute_name}</h5>  
                          <ol>
                            {item?.attribute_vals?.map((attr, index)=>{
                                return (
                                    <li key={index}>{attr}</li>
                                )
                            })
                            }
                           
                          </ol>
                    </div>
                )
            })}
       </Tab>
      }
     
    </Tabs>

    </div>
    <RelatedProducts content={featureproduct} sendDataToParent={AddCartHandleFromchild} sendDataToParentWishlist={AddWishListFromChild}  />
    </div>
    <Modal show={show} onHide={handleClose}  size="md">
        <Modal.Header >
          <Modal.Title>Give Review</Modal.Title>
        </Modal.Header>
        <Modal.Body>
        <div className="form-group mb-3"> 
        <Rating
        onClick={handleRating}
      />
        </div>
        <div className="form-group mb-3"> 
          <input type='text' className='form-control' placeholder='Enter Title' value={title} onChange={(e)=>settitle(e.target.value)} />
      </div>
      <div className="form-group"> 
          <textarea className="form-control" placeholder="Comment Here" value={comment} onChange={(e)=>setcomment(e.target.value)}> </textarea>
      </div>
          
        </Modal.Body>
        <Modal.Footer>
          <button className='btn btn-warning' onClick={handleClose}>
            Close
          </button>
          <button className='btn btn-primary' onClick={SubmitReview}>
           Submit Review
          </button>
        </Modal.Footer>
      </Modal>
      <Lightbox
        open={open}
        carousel={{ finite: lightboxImage.length <= 1 }}
        close={() => setOpen(false)}
        slides={lightboxImage}
        plugins={[Thumbnails, Fullscreen, Zoom]}
      />
  
</div>

 
  )
}

