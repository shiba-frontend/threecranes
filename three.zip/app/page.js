'use client'
import Image from "next/image";
import Banner from "@/component/home/Banner";
import BannerInfo from "@/component/home/BannerInfo";
import ArrivalProduct from "@/component/ArrivalProduct";
import TrendingCollection from "@/component/TrendingCollection";
import FeatureProducts from "@/component/FeatureProducts";
import Testimonial from "@/component/home/Testimonial";
import NewsLetter from "@/component/home/NewsLetter";
import { useEffect, useState } from "react";
import { AddCart, AddWishlist, GetCart, GetHome, GetWishlist } from "@/utils/Apirequest";
import Loader from "@/utils/Loader";
import { useDispatch, useSelector } from "react-redux";
import { GetcartAction, GetWishlistAction, HeaderDropdown } from "@/redux/reducer/DataflowReducer";
import { toast } from "react-toastify";

export default function Home() {

  const [homedata, sethomedata] = useState('')
  const [loading, setloading] = useState(false)
  const datareducer = useSelector((state) => state.Dataflowreducer)
  let dispatch = useDispatch()

  useEffect(()=>{

    GetApiRequest()

     if(datareducer?.isToggle){
                     dispatch(HeaderDropdown(false))
      }

  },[])

  const GetApiRequest = async () =>{
    setloading(true)
    let responsedata =  await GetHome()
    setloading(false)
    if(responsedata?.response_code == 200){
      sethomedata(responsedata?.data)

    }
   
  }




  async function AddCartHandle(item) {

    let price = item?.base_price.replace(',', '')


    setloading(true)

    let body = {
        "product_id": item?.id,
        "product_qty": 1,
        "product_rate": price,
        "variations": []
    }

    const response = await AddCart(body)
    setloading(false)

    if(response?.status){
      //  GetApiRequest()
        let responsedata =  await GetCart()
        dispatch(GetcartAction(responsedata?.data[0]?.cart_items))
        GetApiRequest()
        toast(response?.message)
    } else {
        toast(response?.message)
    }
}


async function AddWishList(item) {
   setloading(true)
  
          let body = {
              "product_id": item?.id,
          }
  
          const response = await AddWishlist(body)
          setloading(false)
  
          if(response?.status){
              let responsedata =  await GetWishlist()
              dispatch(GetWishlistAction(responsedata?.data))
              GetApiRequest()
              toast(response?.message)
          } else {
              toast(response?.message)
          }
}


  return (
    <div className="home">
        {loading && <Loader/>}
        <Banner content={homedata?.section1} />
        <BannerInfo content={homedata?.section2} />
        <ArrivalProduct content={homedata?.section3} sendDataToParent={AddCartHandle} sendDataToParentWishlist={AddWishList}  />
        <TrendingCollection content={homedata?.section4} sendDataToParent={AddCartHandle} sendDataToParentWishlist={AddWishList} />
        <FeatureProducts content={homedata?.section5} sendDataToParent={AddCartHandle} sendDataToParentWishlist={AddWishList} />
        <Testimonial content={homedata?.section6}  />
        <NewsLetter content={homedata?.section7}/>
    </div>
  );
}
